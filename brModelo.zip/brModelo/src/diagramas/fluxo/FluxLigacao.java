/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package diagramas.fluxo;

import controlador.Diagrama;
import desenho.preAnyDiagrama.PreLigacaoSeta;

/**
 *
 * @author ccandido
 */
public class FluxLigacao extends PreLigacaoSeta{

    private static final long serialVersionUID = 1122443174297288831L;

    public FluxLigacao(Diagrama diagrama) {
        super(diagrama);
    }
}
