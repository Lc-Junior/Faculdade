/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package diagramas.atividade;

import controlador.Diagrama;
import desenho.preAnyDiagrama.PreLigacaoSeta;

/**
 *
 * @author ccandido
 */
public class LigacaoAtividade extends PreLigacaoSeta{

    private static final long serialVersionUID = -621549876042127360L;

    public LigacaoAtividade(Diagrama diagrama) {
        super(diagrama);
    }
}
