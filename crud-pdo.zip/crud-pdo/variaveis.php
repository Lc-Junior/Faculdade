<?php
date_default_timezone_set('America/Sao_Paulo');
session_start();

define("URL", "http://localhost/crud-pdo/"); // Definindo url
define("URLASSETS", "http://localhost/crud-pdo/assets/"); // Definindo caminho para acesso a pasta assets

?>