/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidade;

import controle.Produto;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class ManterProduto extends DAO{
  public void inserir(Produto p) throws Exception {
    try {
    abrirBanco();
    String query = "CALL CadastrarProduto(?, ?)";
    pst=(PreparedStatement) con.prepareStatement(query);
    pst.setString(1, p.getNome());
    pst.setDouble(2,p.getPreco());
    pst.execute();
    fecharBanco();
    } catch (Exception e) {
        System.out.println("Erro " + e.getMessage());
    }  
}
  
   public void deletarProduto(Produto p) throws Exception{
	 abrirBanco();
	 String query = "CALL DeletarProduto(?)";
	 pst=(PreparedStatement) con.prepareStatement(query);
	 pst.setInt(1, p.getCodigo());
	 pst.execute();
        JOptionPane.showMessageDialog(null, "Produto deletado com sucesso!");
	fecharBanco();
     }
   
 public ArrayList<Produto> PesquisarProduto() throws Exception {
       ArrayList<Produto> produtos = new ArrayList<Produto>();
         try{
         abrirBanco();  
         String query = "select * FROM produto order by codigo";
         pst = (PreparedStatement) con.prepareStatement(query);
         ResultSet tr = pst.executeQuery();
         Produto p ;
         while (tr.next()){               
           p = new Produto();
           p.setCodigo(tr.getInt("codigo"));
           p.setNome(tr.getString("nome"));
           p.setPreco(tr.getDouble("preco"));
           produtos.add(p);
         } 
         fecharBanco();
       }catch (Exception e){
           System.out.println("Erro " + e.getMessage());
     } 
       return produtos;
     }


  
}