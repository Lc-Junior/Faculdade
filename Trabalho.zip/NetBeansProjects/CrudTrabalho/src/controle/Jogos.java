package controle;

public class Jogos {
 private int Codigo;
 private String Nome_Jogo;
 private double Preco_Jogo;

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public String getNome_Jogo() {
        return Nome_Jogo;
    }

    public void setNome_Jogo(String Nome_Jogo) {
        this.Nome_Jogo = Nome_Jogo;
    }

    public double getPreco_Jogo() {
        return Preco_Jogo;
    }

    public void setPreco_Jogo(double Preco_Jogo) {
        this.Preco_Jogo = Preco_Jogo;
    }

  
 
}
