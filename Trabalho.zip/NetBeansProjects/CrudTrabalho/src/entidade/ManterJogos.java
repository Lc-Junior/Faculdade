/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidade;

import controle.Jogos;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class ManterJogos extends DAO {
    public void inserir(Jogos j) throws Exception {
        try {
            abrirBanco();
            String query = "INSERT INTO jogos(codigo, nome_jogo, preco_jogo) "
                    + "values(null, ?, ?)";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setString(1, j.getNome_Jogo());
            pst.setDouble(2, j.getPreco_Jogo());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }
}