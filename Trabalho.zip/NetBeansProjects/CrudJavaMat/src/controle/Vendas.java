/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

/**
 *
 * @author joao.souza
 */
public class Vendas {
 private int Codigo;
 private String Nome_Vendedor;
 private double Valor_venda;

    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public String getNome_Vendedor() {
        return Nome_Vendedor;
    }

    public void setNome_Vendedor(String Nome_Vendedor) {
        this.Nome_Vendedor = Nome_Vendedor;
    }

    public double getValor_venda() {
        return Valor_venda;
    }

    public void setValor_venda(double Valor_venda) {
        this.Valor_venda = Valor_venda;
    }
 
}
