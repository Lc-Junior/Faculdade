/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidade;

import controle.Jogos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ManterJogos extends DAO {
    public void inserir(Jogos j) throws Exception {
        try {
            abrirBanco();
            String query = "INSERT INTO jogos(codigo, nome, preco) "
                    + "values(null, ?, ?)";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setString(1, j.getNome_Jogo());
            pst.setDouble(2, j.getPreco_Jogo());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }
    
    // método deletar jogos
    public void deletarJogos(Jogos j) throws Exception {
        abrirBanco();
        String query = "delete from jogos where codigo=?";
        pst = (PreparedStatement) con.prepareStatement(query);
        pst.setInt(1, j.getCodigo());
        pst.execute();
        JOptionPane.showMessageDialog(null, "Jogo deletado com sucesso!");
        fecharBanco();
    }
    
    // selecionar jogos
    public ArrayList<Jogos> PesquisarJogos() throws Exception {
        ArrayList<Jogos> jogos = new ArrayList<Jogos>();
        try {
            abrirBanco();
            String query = "select * FROM jogos order by codigo";
            pst = (PreparedStatement) con.prepareStatement(query);
            ResultSet tr = pst.executeQuery();
            Jogos j;
            while (tr.next()) {
                j = new Jogos();
                j.setCodigo(tr.getInt("codigo"));
                j.setNome_Jogo(tr.getString("nome"));
                j.setPreco_Jogo(tr.getDouble("preco"));
                jogos.add(j);
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
        return jogos;
    }
    
    // método para alterar dados do jogo
    public void alterarJogos(Jogos j) throws Exception {
        try {
            abrirBanco();
            String query = "UPDATE jogos SET nome = ?, preco = ? WHERE codigo = ?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setString(1, j.getNome_Jogo());
            pst.setDouble(2, j.getPreco_Jogo());
            pst.setInt(3, j.getCodigo());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Jogo alterado com sucesso!");
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        throw e;
        }
    }
    
}