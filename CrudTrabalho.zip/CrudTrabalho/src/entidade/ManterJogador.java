package entidade;

import controle.Jogador;
import controle.Jogos;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.ResultSet;

public class ManterJogador extends DAO {
    
    public void inserir(Jogador j) throws Exception {
        try {
            abrirBanco();
            String query = "INSERT INTO jogador(codigo, nome, email) "
                    + "values(null, ?, ?)";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setString(1, j.getNome());
            pst.setString(2, j.getEmail());
            pst.execute();
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
    }

    // selecionar jogadores
    public ArrayList<Jogador> PesquisarJogador() throws Exception {
        ArrayList<Jogador> jogadores = new ArrayList<Jogador>();
        try {
            abrirBanco();
            String query = "select * FROM jogador order by codigo";
            pst = (PreparedStatement) con.prepareStatement(query);
            ResultSet tr = pst.executeQuery();
            Jogador j;
            while (tr.next()) {
                j = new Jogador();
                j.setCodigo(tr.getInt("codigo"));
                j.setNome(tr.getString("nome"));
                j.setEmail(tr.getString("email"));
                jogadores.add(j);
            }
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        }
        return jogadores;
    }

    // método deletar jogador
    public void deletarJogador(Jogador j) throws Exception {
        abrirBanco();
        String query = "delete from jogador where codigo=?";
        pst = (PreparedStatement) con.prepareStatement(query);
        pst.setInt(1, j.getCodigo());
        pst.execute();
        JOptionPane.showMessageDialog(null, "Jogador deletado com sucesso!");
        fecharBanco();
    }
    
    // método para alterar dados do jogador
    public void alterarJogador(Jogador j) throws Exception {
        try {
            abrirBanco();
            String query = "UPDATE jogador SET nome = ?, email = ? WHERE codigo = ?";
            pst = (PreparedStatement) con.prepareStatement(query);
            pst.setString(1, j.getNome());
            pst.setString(2, j.getEmail());
            pst.setInt(3, j.getCodigo());
            pst.executeUpdate();
            JOptionPane.showMessageDialog(null, "Jogador alterado com sucesso!");
            fecharBanco();
        } catch (Exception e) {
            System.out.println("Erro " + e.getMessage());
        throw e;
        }
    }
    
    public ArrayList<Jogos> buscarJogosPorJogador(int jogadorId) throws Exception {
    ArrayList<Jogos> jogos = new ArrayList<>();
    try {
        abrirBanco();
        String query = """
            SELECT j.codigo, j.nome, j.preco
            FROM jogos j
            INNER JOIN jogador_jogos jj ON j.codigo = jj.jogo_id
            WHERE jj.jogador_id = ?
        """;
        pst = con.prepareStatement(query);
        pst.setInt(1, jogadorId);
        ResultSet rs = pst.executeQuery();
        
        while (rs.next()) {
            Jogos jogo = new Jogos();
            jogo.setCodigo(rs.getInt("codigo"));
            jogo.setNome_Jogo(rs.getString("nome"));
            jogo.setPreco_Jogo(rs.getDouble("preco"));
            jogos.add(jogo);
        }
        fecharBanco();
    } catch (Exception e) {
        System.out.println("Erro " + e.getMessage());
    }
    return jogos;
}
    
    public void associarJogoAoJogador(int jogadorId, int jogoId) throws Exception {
    try {
        abrirBanco();
        String query = "INSERT INTO jogador_jogos (jogador_id, jogo_id) VALUES (?, ?)";
        pst = con.prepareStatement(query);
        pst.setInt(1, jogadorId);
        pst.setInt(2, jogoId);
        pst.execute();
        fecharBanco();
        JOptionPane.showMessageDialog(null, "Jogo associado ao jogador com sucesso!");
    } catch (Exception e) {
        System.out.println("Erro ao associar jogo: " + e.getMessage());
    }
}
}