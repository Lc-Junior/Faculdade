package testafuncionarios;

public class Secretarias extends Funcionario{
    
}
