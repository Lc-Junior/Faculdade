package br.com.controle;

public class Parcelas {
    private double valor;
    private int parcela;

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public int getParcela() {
        return parcela;
    }

    public void setParcela(int parcela) {
        this.parcela = parcela;
    }
    
    public double calcularValor(){
        if(this.parcela <= 1 ){
            return this.valor-(this.valor*0.1);
        }
        else if(this.parcela <= 3){
            return this.valor+(this.valor*0.05);
        }
    
            return this.valor+(this.valor*0.1);
    }
 
}
