package br.com.visao;

import br.com.controle.Parcelas;
import javax.swing.JOptionPane;

public class Objeto {
    public static void main(String[] args){
       Parcelas p = new Parcelas();
       p.setValor(Double.valueOf(JOptionPane.showInputDialog("Digite o valor da venda: ")));
       p.setParcela(Integer.valueOf(JOptionPane.showInputDialog("Digite quantas parcelas deseja: ")));
       JOptionPane.showMessageDialog(null, "O valor total sairá por: " + p.calcularValor());
    }
}
