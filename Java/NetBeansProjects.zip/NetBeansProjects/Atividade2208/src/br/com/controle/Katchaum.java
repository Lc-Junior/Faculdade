/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.controle;

/**
 *
 * @author 202211684
 */
public class Katchaum {
    private double kmi;
    private double kmf;
    private double litros;

    public double getKmi() {
        return kmi;
    }

    public void setKmi(double kmi) {
        this.kmi = kmi;
    }

    public double getKmf() {
        return kmf;
    }

    public void setKmf(double kmf) {
        this.kmf = kmf;
    }

    public double getLitros() {
        return litros;
    }

    public void setLitros(double litros) {
        this.litros = litros;
    }
    
    public double calcularConsumo(){
        return (this.kmf-this.kmi)/this.litros;
    }
    
}
