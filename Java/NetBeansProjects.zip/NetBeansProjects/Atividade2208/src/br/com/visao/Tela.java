package br.com.visao;

import br.com.controle.Katchaum;
import javax.swing.JOptionPane;


public class Tela {
    public static void main(String[] args){
        Katchaum marquinhos = new Katchaum();
        marquinhos.setKmi(Double.valueOf(JOptionPane.showInputDialog("Digite a quilometragem inicial: ")));
        marquinhos.setKmf(Double.valueOf(JOptionPane.showInputDialog("Digite a quilometragem final: ")));
        marquinhos.setLitros(Double.valueOf(JOptionPane.showInputDialog("Digite quantos litros foram abastecidos: ")));
            JOptionPane.showMessageDialog(null, "Seu carro fez uma média de: "+ marquinhos.calcularConsumo() + " Litros!");
    }
}
