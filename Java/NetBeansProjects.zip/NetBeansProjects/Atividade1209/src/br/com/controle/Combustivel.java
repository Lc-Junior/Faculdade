package br.com.controle;

public class Combustivel {
    private double litros;
    private char combustivel;
    private double resultado=0;

    public double getLitros() {
        return litros;
    }

    public void setLitros(double litros) {
        this.litros = litros;
    }

    public char getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(char combustivel) {
        this.combustivel = combustivel;
    }
    
    public double calculoAlcool(){
        if(this.combustivel == 'A' && this.litros <=20){
            resultado = this.litros*5.90;
            resultado = this.resultado-(this.resultado*(this.litros*0.03));
        }
        else if(this.combustivel == 'A' && this.litros > 20){
            resultado = this.litros*5.90;
            resultado = this.resultado-(this.resultado*(this.litros*0.05));
        }
        return resultado;
    }
    public double calculoGasolna(){
        if(this.combustivel == 'G' && this.litros <=20){
            resultado = this.litros*6.30;
            resultado = this.resultado-(this.resultado*(this.litros*0.04));
        }
        else if(this.combustivel == 'G' && this.litros > 20){
            resultado = this.litros*6.30;
            resultado = this.resultado-(this.resultado*(this.litros*0.06));
        }
        return resultado;
    }
   
}
