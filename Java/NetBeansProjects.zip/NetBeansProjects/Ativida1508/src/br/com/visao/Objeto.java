package br.com.visao;

import br.com.controle.Semestre;
import javax.swing.JOptionPane;

public class Objeto {
    public static void main(String[] args) {
       Semestre s = new Semestre();
       s.setNota1(Integer.valueOf(JOptionPane.showInputDialog("Digite a primeira nota: ")));
       s.setNota2(Integer.valueOf(JOptionPane.showInputDialog("Digite a segunda nota: ")));
       if(s.calcularMedia() < 4){
           JOptionPane.showMessageDialog(null, s.calcularMedia() + "\nReprovado!");
       }
       else if(s.calcularMedia()> 4 && s.calcularMedia() < 6){
           JOptionPane.showMessageDialog(null, s.calcularMedia() + "\nRecuperação!");
       }
       else{
           JOptionPane.showMessageDialog(null, s.calcularMedia() + "\nAprovado!");
       }
    }
}
