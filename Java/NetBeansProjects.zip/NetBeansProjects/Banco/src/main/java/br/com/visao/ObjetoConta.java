package br.com.visao;

import br.com.controle.ContaCorrente;

public class ObjetoConta {
    public static void main(String[] args) {
        ContaCorrente cc = new ContaCorrente();
        
    }
}
