package br.com.controle;

public class Conta {

        private double saldo = 0;
        private double saque;
        private double deposito;

        public double getSaldo() {
            return saldo;
        }

        public void setSaldo(double saldo) {
            this.saldo = saldo;
        }

        public double getSaque() {
            return saque;
        }

        public void setSaque(double saque) {
            this.saque = saque;
            this.saldo -= saque;
        }

        public double getDeposito() {
            return deposito;
        }

        public void setDeposito(double deposito) {
            this.deposito = deposito;
            this.saldo += deposito;
        }
}
