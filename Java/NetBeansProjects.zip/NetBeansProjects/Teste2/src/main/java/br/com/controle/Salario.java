package br.com.controle;

public class Salario {
    private double salarioantigo;
    private double salario;
    private double diferenca;
    private char cargo;

    public double getSalarioantigo() {
        return salarioantigo;
    }

    public void setSalarioantigo(double salarioantigo) {
        this.salarioantigo = salarioantigo;
    }
   

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = this.salarioantigo;
    }

    public double getDiferenca() {
        return diferenca;
    }

    public void setDiferenca(double diferenca) {
        this.diferenca = diferenca;
    }

    public char getCargo() {
        return cargo;
    }

    public void setCargo(char cargo) {
        this.cargo = cargo;
    }
    
    public double calculoSalario(){
        if(this.cargo == 'G'){
            this.salario = this.salario+(this.salario*0.10);
        }
        else if(this.cargo == 'E'){
            this.salario = this.salario+(this.salario*0.20);
        }
        else if(this.cargo == 'T'){
            this.salario = this.salario+(this.salario*0.30);
        }
        else if(this.cargo == 'O'){
            this.salario = this.salario+(this.salario*0.40);
        }
        this.diferenca = this.salario - this.salarioantigo;
        return this.salario;
    }
}
