package br.com.controle;

public class Dobro {
    private int valor;

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
    
    public int calcularDobro(){
        return this.valor*2;
    }
}