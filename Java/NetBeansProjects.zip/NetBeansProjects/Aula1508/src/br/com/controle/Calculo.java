package br.com.controle;

public class Calculo {
    private int valor;

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
    
    public int calculaDobro(){
        return valor*2;
    }
}
