/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.controle;

/**
 *
 * @author 202211684
 */
public class Teste {
    private double valor;
    private double valordesconto;
    private int especial;

    public int getEspecial() {
        return especial;
    }

    public void setEspecial(int especial) {
        this.especial = especial;
    }

    public double getValordesconto() {
        return valordesconto;
    }

    public void setValordesconto(double valordesconto) {
        this.valordesconto = valordesconto;
    }

    public double getValor() {
        return valor;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }
    public double soma(){
        this.valordesconto = this.valor + this.valor*0.73;
        if(this.especial == 1){
            this.valordesconto = this.valordesconto - this.valordesconto*0.2;
            return this.valordesconto;
        }
    return this.valordesconto;
    }
}
